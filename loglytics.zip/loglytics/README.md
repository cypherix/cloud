# LogLytics - Codeathon Project(Log Analysis)


## Prerequisites

Before you begin, ensure you have the following installed on your system:

- **Python 3.7 or higher**
- **pip** (Python package installer)
- **Virtual environment tool** (venv or virtualenv)

## Installation

Follow these steps to set up and run LogLytics:

### 1. Extract the Project

Extract the provided ZIP file to your desired location:

```bash
# On Windows
# Right-click the ZIP file and select "Extract All..."
```

### 2. Navigate to the Project Directory

```bash
cd loglytics
```

### 3. Create a Virtual Environment

It's recommended to use a virtual environment to avoid conflicts with other Python projects:

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows
venv\Scripts\activate
```

### 4. Install Dependencies

Install the required Python packages using pip:

```bash
pip install -r requirements.txt
```

If a `requirements.txt` file is not provided, you can install Flask directly:

```bash
pip install Flask
```

### 5. Create Required Directories

The application requires a storage directory for uploaded files:

```bash
# The application will automatically create the 'storage' directory
# You can also create it manually if needed
mkdir storage
```

## Running the Application

### 1. Start the Development Server

With your virtual environment activated, run the application:

```bash
python run.py
```

### 2. Access the Application

Open your web browser and navigate to:

```
http://localhost:5000
```

You should see the LogLytics welcome page.

## Usage Guide

### 1. Getting Started

1. Click the "Get Started" button on the welcome page
2. You'll be redirected to the upload page after a brief loading animation

### 2. Uploading Log Files

1. On the upload page, either:
   - Click "Browse Files" to select a `.txt` log file
   - Drag and drop a file onto the upload area
2. Selected files must be `.txt` format and under 20MB
3. Click the "Upload" button to process your file
4. After successful upload, you'll be redirected to the dashboard

### 3. Analyzing Logs

The dashboard provides several analysis and filtering options:

#### Basic Search
- Enter keywords in the "Search Keywords" field
- Use "Exclude Keywords" to filter out unwanted terms
- Toggle "Case-insensitive" for case-sensitive searches
- Enable "Whole word matching" for exact word matches
- Choose between AND/OR logic for multi-term searches

#### Advanced Filtering
- Filter by severity level (ERROR, WARN, INFO, DEBUG)
- Set context lines to show surrounding log entries
- Hide duplicate lines to reduce noise

#### Structured Log Features
- For key-value pair logs, column filtering becomes available
- Select a column, operator, and value to filter structured data

#### Results Management
- Copy results to clipboard with the "Copy" button
- Export filtered results to a file with the "Export" button
- Reset all filters with the "Reset Filters" button

### 4. Understanding the Interface

#### Statistics Panel
Shows key metrics about your log file:
- **Total**: Total number of lines in the file
- **Matches**: Number of lines matching current filters
- **Unique**: Number of unique lines (duplicates removed)
- **Size**: File size in megabytes

#### Log Display Area
- Line numbers are shown on the left for easy reference
- Matching search terms are highlighted in yellow
- Severity levels are color-coded (red for ERROR, orange for WARN, etc.)
- Timestamps are highlighted in green
- Context lines appear in italics when context view is enabled

## Project Structure

```
loglytics/
├── app/                    # Main application package
│   ├── __init__.py        # Application factory
│   ├── routes/            # Route handlers
│   │   ├── main.py       # Main pages (index, loading)
│   │   ├── upload.py     # File upload functionality
│   │   └── dashboard.py  # Log analysis dashboard
│   ├── templates/         # HTML templates
│   └── static/            # Static assets
│       └── js/           # JavaScript files
├── storage/               # Uploaded files storage (created automatically)
├── config.py             # Application configuration
├── run.py                # Application entry point
├── requirements.txt      # Python dependencies (if provided)
└── README.md             # This file
```

## Configuration

The application can be configured through `config.py`:

- **UPLOAD_FOLDER**: Directory for storing uploaded files (default: 'storage')
- **MAX_CONTENT_LENGTH**: Maximum file upload size (default: 20MB)

## Troubleshooting

### Common Issues

1. **"No module named flask"**
   - Ensure your virtual environment is activated
   - Install Flask: `pip install Flask`

2. **Permission denied when creating storage directory**
   - Run the application with appropriate permissions
   - Manually create the 'storage' directory

3. **Upload fails with "Invalid file type"**
   - Ensure you're uploading a `.txt` file
   - Check that the file size is under 20MB

4. **Dashboard shows "Loading log data..." indefinitely**
   - Refresh the page
   - Check that the file was uploaded successfully
   - Verify the storage directory contains your file

### Browser Compatibility

LogLytics works best with modern browsers:
- Google Chrome (recommended)
- Microsoft Edge

Internet Explorer is not supported.

## Authors

- **Yogesh Murugarathinam**
- **Anushka Sachin**
- **Jenil Shah**
- **Niluptal Baruah**
- **Rakesh Prasanna**

---

**Happy Log Analyzing with LogLytics!**