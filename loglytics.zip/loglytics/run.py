"""
Main Application Runner for LogLytics

This is the entry point for running the LogLytics Flask application.
It creates the Flask app instance using the application factory
pattern and starts the development server.

The script:
1. Adds the current directory to Python path for module importing
2. Imports the create_app function from the app package
3. Creates the Flask application instance
4. Runs the development server when executed directly

This approach allows for:
- Easy execution of the application with 'python run.py'
- Proper module path setup for imports
- Clean separation between app creation and execution
- Debug mode enabled for development
"""

import sys
import os

# Add the current directory to Python path
# This ensures that modules can be imported correctly
# regardless of where the script is executed from
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the application factory function
# This function creates and configures the Flask app
from app import create_app

# Create the Flask application instance
# Using the application factory pattern
app = create_app()

# Run the development server when this script is executed directly
# The debug=True flag enables auto-reloading during development
# and provides detailed error pages for easier debugging
if __name__ == "__main__":
    app.run(debug=True)