"""
Application Factory Module for LogLytics

This module implements the Flask application factory pattern,
which is a recommended practice for structuring Flask applications.
It creates and configures the Flask application instance.

The factory function:
1. Creates the Flask app instance
2. Loads configuration settings
3. Registers Flask blueprints for different functionality areas
4. Sets up any additional extensions or middleware
5. Returns the configured app instance

This approach provides several benefits:
- Enables easier testing with different configurations
- Allows multiple app instances if needed
- Provides better separation of concerns
- Makes configuration management cleaner
"""

from flask import Flask
from config import Config


def create_app():
    """
    Application factory function that creates and configures the Flask app.
    
    This function follows the Flask application factory pattern:
    https://flask.palletsprojects.com/en/2.0.x/patterns/appfactories/
    
    The function:
    1. Creates a Flask application instance
    2. Loads configuration from config.py using the Config class
    3. Registers blueprints for different functional areas
    4. Returns the fully configured application
    
    Returns:
        Flask: Configured Flask application instance
    """
    # Create Flask application instance
    app = Flask(__name__)
    
    # Load configuration from the Config class in config.py
    # This includes settings like upload folder paths, file size limits, etc.
    app.config.from_object(Config)
    
    # Register blueprints for different functional areas
    # Each blueprint handles a specific set of routes
    
    # Main routes: Home page and loading page
    from app.routes.main import main_bp
    # Upload routes: File upload functionality
    from app.routes.upload import upload_bp
    # Dashboard routes: Log analysis and display
    from app.routes.dashboard import dashboard_bp
    
    # Register the blueprints with the Flask application
    # This connects the route handlers to the application
    app.register_blueprint(main_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(dashboard_bp)
    
    # Return the fully configured Flask application
    return app