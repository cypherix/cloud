"""
Upload Routes Module for LogLytics

This module handles file upload functionality:
- Rendering the upload page (/upload GET)
- Processing file uploads (/upload POST)
- Validating file types and sizes
- Storing uploaded files in UUID-named directories

The upload process:
1. User selects/uploads a .txt file
2. File is validated for type (.txt) and size (20MB limit)
3. A unique UUID session ID is generated
4. File is saved in a directory named after the UUID
5. User is redirected to the dashboard with the UUID as a slug
"""

import os
import uuid
from flask import Blueprint, render_template, request, jsonify, current_app
from werkzeug.utils import secure_filename

# Create the upload blueprint
upload_bp = Blueprint('upload', __name__)

# Define allowed file extensions
ALLOWED_EXTENSIONS = {'txt'}

def allowed_file(filename):
    """
    Check if the uploaded file has an allowed extension.
    
    Args:
        filename (str): Name of the file to check
        
    Returns:
        bool: True if file extension is allowed, False otherwise
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@upload_bp.route('/upload', methods=['GET', 'POST'])
def upload_page():
    """
    Handle both GET and POST requests for the upload page.
    
    GET: Render the upload page template
    POST: Process the file upload, validate, save, and return JSON response
    
    For POST requests:
    - Validates that a file was uploaded
    - Checks file type (.txt only)
    - Generates a unique UUID for the session
    - Creates a directory for the file using the UUID
    - Saves the file in the directory
    - Returns JSON with success status and UUID slug for dashboard redirect
    
    Returns:
        For GET: Rendered upload.html template
        For POST: JSON response with success/failure and slug for redirect
    """
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file part'})
        
        file = request.files['file']
        
        # If user does not select file, browser submits empty part without filename
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'})
        
        # Validate and process the uploaded file
        if file and allowed_file(file.filename):
            # Create unique session ID for this upload session
            session_id = str(uuid.uuid4())
            
            # Get upload folder from app config
            upload_folder = current_app.config['UPLOAD_FOLDER']
            
            # Create directory with UUID to isolate this session's files
            session_dir = os.path.join(upload_folder, session_id)
            os.makedirs(session_dir, exist_ok=True)
            
            # Secure filename to prevent directory traversal attacks and save
            filename = secure_filename(file.filename)
            file_path = os.path.join(session_dir, filename)
            file.save(file_path)
            
            # Return success response with slug (UUID) for dashboard redirect
            return jsonify({'success': True, 'slug': session_id})
        else:
            return jsonify({'success': False, 'error': 'Invalid file type. Only .txt files are allowed.'})
    
    # If GET request, render the upload page
    return render_template('upload.html')