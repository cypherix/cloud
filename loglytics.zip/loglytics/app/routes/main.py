"""
Main Routes Module for LogLytics

This module handles the primary navigation routes for the application:
- Home page (/)
- Loading page (/loading) - transitional page between home and upload

The routes are organized using Flask Blueprints for better modularity.
"""

from flask import Blueprint, render_template

# Create the main blueprint for primary routes
main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    """
    Render the main landing page of the application.
    
    This is the entry point for users visiting the application.
    It displays a welcome message and a "Get Started" button
    that redirects to the loading page.
    
    Returns:
        Rendered index.html template
    """
    return render_template('index.html')

@main_bp.route('/loading')
def loading():
    """
    Render the loading page with redirect to upload.
    
    This transitional page provides a smooth user experience
    between the main page and the upload page. It shows a 
    loading animation before automatically redirecting to
    the upload page after a short delay.
    
    Returns:
        Rendered loading.html template
    """
    return render_template('loading.html')