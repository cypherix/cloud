"""
Dashboard Routes Module for LogLytics

This module handles the main dashboard functionality:
- Rendering the dashboard page with log analysis (/dashboard/<uuid:session_id>)
- Reading uploaded log files from session directories
- Analyzing log content to extract statistics
- Passing data to the dashboard template for client-side processing

The dashboard route:
1. Takes a UUID session ID as a URL parameter
2. Locates the corresponding session directory
3. Reads the uploaded log file(s)
4. Analyzes the content for statistics
5. Renders the dashboard template with file content and statistics

The analysis includes:
- Line counts and unique line identification
- Severity level distribution (ERROR, WARN, INFO, DEBUG)
- Timestamp distribution
- Common pattern frequency
- Structured log format detection
"""

from flask import Blueprint, render_template, abort, current_app
import os
import uuid
import re
from datetime import datetime

# Create the dashboard blueprint for organizing routes
dashboard_bp = Blueprint('dashboard', __name__)

def analyze_log_content(lines):
    """
    Analyze log content to extract key statistics and patterns.
    
    This function performs several analyses on the log content:
    - Counts total lines and unique lines
    - Identifies severity levels (ERROR, WARN, INFO, DEBUG)
    - Extracts timestamp distributions
    - Detects common patterns and keywords
    - Determines if logs are in a structured format
    
    Args:
        lines (list): List of strings, each representing a line from the log file
        
    Returns:
        dict: Dictionary containing various statistics about the log content
    """
    # Initialize statistics dictionary with default values
    stats = {
        'total_lines': len(lines),
        'error_count': 0,
        'warn_count': 0,
        'info_count': 0,
        'debug_count': 0,
        'timestamp_distribution': {},
        'severity_counts': {},
        'frequent_patterns': {},
        'structured_format': 'unstructured'  # Default assumption
    }
    
    # Try to detect if logs are in a structured format (e.g., key-value pairs or JSON)
    # Check first 50 lines to determine pattern for efficiency
    structured_line_count = 0
    for line in lines[:50]:  # Check first 50 lines to determine pattern
        # Key-value pair patterns (e.g., "key=value" or "[key]=value")
        if '=' in line and (' ' in line.split('=')[0][:20] or line.strip().startswith('[')):  # Key-value pair
            structured_line_count += 1
        # JSON-like patterns
        elif line.strip().startswith('{') and line.strip().endswith('}'):  # JSON like
            structured_line_count += 1
    
    # If more than half of the sampled lines are structured, mark as key_value format
    if structured_line_count > 25:  # If more than half are structured
        stats['structured_format'] = 'key_value'
    
    # Process each line to extract statistics
    for line in lines:
        # Count severity levels by looking for standard log patterns
        if '[ERROR]' in line:
            stats['error_count'] += 1
        elif '[WARN]' in line:
            stats['warn_count'] += 1
        elif '[INFO]' in line:
            stats['info_count'] += 1
        elif '[DEBUG]' in line:
            stats['debug_count'] += 1
        
        # Extract timestamps using regex pattern matching
        timestamp_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})', line)
        if timestamp_match:
            timestamp_str = timestamp_match.group(1)
            date_str = timestamp_str.split(' ')[0]  # Extract date part
            # Count timestamp occurrences by date
            if date_str in stats['timestamp_distribution']:
                stats['timestamp_distribution'][date_str] += 1
            else:
                stats['timestamp_distribution'][date_str] = 1
        
        # Count frequency of common patterns in log lines
        # This is a simplified example - in real implementation you might want more sophisticated pattern detection
        for pattern in ['ERROR', 'WARN', 'INFO', 'DEBUG', 'exception', 'timeout', 'failure']:
            if pattern.lower() in line.lower():
                if pattern in stats['frequent_patterns']:
                    stats['frequent_patterns'][pattern] += 1
                else:
                    stats['frequent_patterns'][pattern] = 1
    
    # Aggregate severity counts for easier access
    stats['severity_counts'] = {
        'ERROR': stats['error_count'],
        'WARN': stats['warn_count'],
        'INFO': stats['info_count'],
        'DEBUG': stats['debug_count']
    }
    
    return stats

@dashboard_bp.route('/dashboard/<uuid:session_id>')
def dashboard_page(session_id):
    """
    Render the dashboard page for a specific log file session.
    
    This route takes a UUID session ID, locates the corresponding
    session directory, reads the uploaded log file, analyzes its
    content for statistics, and renders the dashboard template.
    
    Args:
        session_id (uuid): UUID identifying the upload session
        
    Returns:
        Rendered dashboard.html template with file content and statistics
        
    Raises:
        404: If the session directory doesn't exist
    """
    # Convert UUID to string for directory operations
    session_str = str(session_id)
    
    # Get upload folder from app config
    upload_folder = current_app.config['UPLOAD_FOLDER']
    session_dir = os.path.join(upload_folder, session_str)
    
    # Check if the session directory exists - return 404 if not found
    if not os.path.exists(session_dir):
        abort(404)
    
    # Look for uploaded files in the session directory
    files = []
    for filename in os.listdir(session_dir):
        filepath = os.path.join(session_dir, filename)
        # Only include actual files (not directories)
        if os.path.isfile(filepath):
            files.append({
                'name': filename,
                'size': os.path.getsize(filepath),
                'path': filepath
            })
    
    # Read the content of the first file if available and analyze it
    file_content = []
    stats = {}
    if files:
        try:
            # Open the first uploaded file for reading
            with open(files[0]['path'], 'r', encoding='utf-8', errors='ignore') as f:
                file_content = f.readlines()
            
            # Analyze the log content for statistics
            stats = analyze_log_content(file_content)
        except Exception as e:
            # Handle file reading errors gracefully
            file_content = [f"Error reading file content: {str(e)}"]
            stats = {
                'total_lines': 0,
                'error_count': 0,
                'warn_count': 0,
                'info_count': 0,
                'debug_count': 0,
                'timestamp_distribution': {},
                'severity_counts': {},
                'frequent_patterns': {},
                'structured_format': 'unstructured'
            }
    
    # Render the dashboard template with all necessary data
    return render_template('dashboard.html', 
                          session_id=session_str, 
                          file_name=files[0]['name'] if files else 'No file',
                          files=files, 
                          file_content=file_content,
                          stats=stats)