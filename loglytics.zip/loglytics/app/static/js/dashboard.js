/**
 * LogAnalyzer Class
 * 
 * This class handles all the log analysis functionality for the LogLytics dashboard.
 * It implements a comprehensive set of features for processing, filtering, and displaying log data.
 * 
 * Main responsibilities:
 * - Loading and validating log data from the server
 * - Managing filter state and applying complex filtering logic
 * - Rendering log lines in an optimized display
 * - Handling multi-term search with various logic operators (AND/OR)
 * - Applying highlighting to matching terms
 * - Managing context lines display around matches
 * - Handling structured log formats (key-value pairs)
 * - Providing statistics about the log data
 * - Supporting export and copy operations
 */
class LogAnalyzer {
  /**
   * Initializes the LogAnalyzer with file content and statistics
   * @param {Array} fileContent - Array of strings representing log lines
   * @param {Object} stats - Statistics about the log file
   */
  constructor(fileContent, stats) {
    this.fileContent = fileContent;
    this.stats = stats;
    
    // Centralized DOM selector references for easy maintenance
    this.SELECTORS = {
      searchInput: '#searchInput',           // Input field for search terms
      excludeInput: '#excludeInput',         // Input field for terms to exclude
      caseInsensitive: '#caseInsensitive',   // Checkbox for case-insensitive search
      wholeWord: '#wholeWord',              // Checkbox for whole word matching
      andLogic: '#andLogic',                // Checkbox for AND logic (all terms must match)
      contextLines: '#contextLines',        // Number input for context lines before/after matches
      severityFilter: '#severityFilter',     // Dropdown for severity level filtering
      hideDuplicates: '#hideDuplicates',    // Checkbox to toggle duplicate line hiding
      columnSelect: '#columnSelect',        // Dropdown for column-based filtering
      columnOperator: '#columnOperator',    // Dropdown for column match operator
      columnValue: '#columnValue',          // Input for column value to match
      dateFrom: '#dateFrom',                // Input for date range start
      dateTo: '#dateTo',                    // Input for date range end
      columnFilterSection: '#columnFilterSection', // Container for column filter controls
      emptyColumnFilter: '#emptyColumnFilter', // Placeholder for column filter when hidden
      searchButton: '#searchButton',        // Search execution button
      resetButton: '#resetButton',          // Reset all filters button
      copyResults: '#copyResults',          // Copy results to clipboard button
      exportResults: '#exportResults',      // Export results button
      logContent: '#logContent',            // Container for displaying log lines
      totalLines: '#totalLines',            // Display element for total line count
      matchCount: '#matchCount',            // Display element for match count
      uniqueLines: '#uniqueLines',          // Display element for unique line count
      fileSize: '#fileSize',                // Display element for file size
      resultsInfo: '#resultsInfo'           // Display element for results count
    };
    
    this.init();
  }

  /**
   * Initialize the dashboard by performing all necessary setup operations
   * This is the main entry point for the dashboard after data loading
   */
  init() {
    this.validateData();
    this.updateStats();
    this.setupStructuredLogDetection();
    this.setupEventListeners();
    this.displayLogContent(this.fileContent);
  }

  /**
   * Validates if the log data exists and displays appropriate message if not
   * @returns {boolean} - True if data is valid, false otherwise
   */
  validateData() {
    if (!this.fileContent || this.fileContent.length === 0) {
      document.querySelector(this.SELECTORS.logContent).innerHTML = 
        '<div class="p-4 text-center text-stone-400">No log data available for this session.</div>';
      document.querySelector(this.SELECTORS.resultsInfo).textContent = '0 results';
      return false;
    }
    return true;
  }

  /**
   * Updates the statistics panel with key metrics about the log file
   * Metrics include: total lines, unique lines, file size, and result count
   */
  updateStats() {
    const totalLines = this.fileContent.length;
    const uniqueLines = new Set(this.fileContent).size;
    const fileSize = (this.fileContent.join('\n').length / (1024 * 1024)).toFixed(2);

    document.querySelector(this.SELECTORS.totalLines).textContent = totalLines;
    document.querySelector(this.SELECTORS.uniqueLines).textContent = uniqueLines;
    document.querySelector(this.SELECTORS.fileSize).textContent = `${fileSize}MB`;

    document.querySelector(this.SELECTORS.resultsInfo).textContent = `${totalLines} results`;
  }

  /**
   * Detects if the log file contains structured data and shows appropriate filters
   * For structured logs, enables column-based filtering options
   */
  setupStructuredLogDetection() {
    if (this.stats.structured_format && this.stats.structured_format !== 'unstructured') {
      document.querySelector(this.SELECTORS.columnFilterSection).style.display = 'block';
      document.querySelector(this.SELECTORS.emptyColumnFilter).style.display = 'none';

      const columns = this.detectColumns(this.fileContent.slice(0, 10));
      const columnSelect = document.querySelector(this.SELECTORS.columnSelect);

      columns.forEach(col => {
        const option = document.createElement('option');
        option.value = col.toLowerCase();
        option.textContent = col;
        columnSelect.appendChild(option);
      });
    }
  }

  /**
   * Detects potential columns in structured logs based on key-value patterns
   * This function identifies potential columns by looking for key=value patterns
   * @param {Array} lines - Array of log lines to analyze
   * @returns {Array} - Array of detected column names
   */
  detectColumns(lines) {
    const columns = new Set();

    for (const line of lines) {
      if (line.includes('=') || line.includes(':')) {
        const matches = line.match(/(\w+(?==|:))/g);
        if (matches) {
          matches.forEach(col => columns.add(col.trim()));
        }
      }
    }

    return Array.from(columns);
  }

  /**
   * Sets up all event listeners for the dashboard UI elements
   * This includes buttons, inputs, and keyboard shortcuts
   */
  setupEventListeners() {
    // Search button
    document.querySelector(this.SELECTORS.searchButton).addEventListener('click', () => this.performSearch());

    // Reset button
    document.querySelector(this.SELECTORS.resetButton).addEventListener('click', () => this.resetFilters());

    // Copy results button
    document.querySelector(this.SELECTORS.copyResults).addEventListener('click', () => this.copyResults());

    // Export results button
    document.querySelector(this.SELECTORS.exportResults).addEventListener('click', () => this.exportResults());

    // Enter key triggers search
    document.querySelector(this.SELECTORS.searchInput).addEventListener('keyup', (event) => {
      if (event.key === 'Enter') this.performSearch();
    });

    document.querySelector(this.SELECTORS.columnValue).addEventListener('keyup', (event) => {
      if (event.key === 'Enter') this.performSearch();
    });

    document.querySelector(this.SELECTORS.excludeInput).addEventListener('keyup', (event) => {
      if (event.key === 'Enter') this.performSearch();
    });
  }

  /**
   * Main search algorithm that applies multiple filter types sequentially
   * 
   * The algorithm follows this order:
   * 1. Column-based filtering (if enabled)
   * 2. Multi-term search (with AND/OR logic)
   * 3. Exclude keyword filtering
   * 4. Severity level filtering
   * 5. Duplicate removal
   * 6. Context line expansion
   * 
   * Each filter type can be enabled or disabled independently.
   * The algorithm builds a filtered subset of lines progressively.
   * 
   * @returns {undefined} - Updates the UI with filtered results
   */
  performSearch() {
    // Capture all current filter values from the UI
    const searchTerm = document.querySelector(this.SELECTORS.searchInput).value.trim();
    const excludeTerm = document.querySelector(this.SELECTORS.excludeInput).value.trim();
    const caseInsensitive = document.querySelector(this.SELECTORS.caseInsensitive).checked;
    const wholeWord = document.querySelector(this.SELECTORS.wholeWord).checked;
    const andLogic = document.querySelector(this.SELECTORS.andLogic).checked;
    const contextLines = parseInt(document.querySelector(this.SELECTORS.contextLines).value) || 0;
    const severityFilter = document.querySelector(this.SELECTORS.severityFilter).value;
    const hideDuplicates = document.querySelector(this.SELECTORS.hideDuplicates).checked;

    // Column-based filter values
    const columnSelect = document.querySelector(this.SELECTORS.columnSelect);
    const columnOperator = document.querySelector(this.SELECTORS.columnOperator);
    const columnValue = document.querySelector(this.SELECTORS.columnValue);

    const columnFilterEnabled = columnSelect.value && columnValue.value.trim();
    const column = columnFilterEnabled ? columnSelect.value : null;
    const operator = columnFilterEnabled ? columnOperator.value : null;
    const value = columnFilterEnabled ? columnValue.value.trim() : null;

    // Start with a copy of the original file content
    let filteredLines = [...this.fileContent];
    let matchCount = 0;
    let uniqueLines = new Set();

    // Apply column-based filter first if enabled
    // This is particularly useful for structured logs with key-value pairs
    if (columnFilterEnabled) {
      filteredLines = filteredLines.filter(line => {
        if (caseInsensitive) {
          var pattern = new RegExp(`(${column})[^=]*=[^=]*([^\\s\\n]+)`, 'i');
        } else {
          var pattern = new RegExp(`(${column})[^=]*=[^=]*([^\\s\\n]+)`);
        }

        const match = line.match(pattern);
        if (match) {
          const foundValue = match[2]; // The value part after the equals sign

          // Apply the selected operator to compare values
          switch (operator) {
            case 'equals':
              if (caseInsensitive) {
                return foundValue.toLowerCase() === value.toLowerCase();
              } else {
                return foundValue === value;
              }
            case 'contains':
              if (caseInsensitive) {
                return foundValue.toLowerCase().includes(value.toLowerCase());
              } else {
                return foundValue.includes(value);
              }
            case 'starts':
              if (caseInsensitive) {
                return foundValue.toLowerCase().startsWith(value.toLowerCase());
              } else {
                return foundValue.startsWith(value);
              }
            case 'ends':
              if (caseInsensitive) {
                return foundValue.toLowerCase().endsWith(value.toLowerCase());
              } else {
                return foundValue.endsWith(value);
              }
            default:
              return true;
          }
        }
        return false; // If column not found in line, exclude it
      });
    }

    // Apply search if a search term is provided
    // This handles multi-term searches with AND/OR logic
    if (searchTerm) {
      const searchTerms = searchTerm.split(/\s+/).filter(term => term.length > 0);
      if (searchTerms.length > 0) {
        filteredLines = filteredLines.filter(line => {
          let matches = false;

          for (const term of searchTerms) {
            let termMatches = false;

            // Build regex pattern based on case sensitivity and whole word options
            if (caseInsensitive) {
              if (wholeWord) {
                const regex = new RegExp(`\\b${this.escapeRegExp(term)}\\b`, 'i');
                termMatches = regex.test(line);
              } else {
                termMatches = line.toLowerCase().includes(term.toLowerCase());
              }
            } else {
              if (wholeWord) {
                const regex = new RegExp(`\\b${this.escapeRegExp(term)}\\b`);
                termMatches = regex.test(line);
              } else {
                termMatches = line.includes(term);
              }
            }

            if (andLogic) {
              // For AND logic, all terms must match
              if (!termMatches) {
                return false;
              }
            } else {
              // For OR logic, any term matching is sufficient
              if (termMatches) {
                matches = true;
                break;
              }
            }
          }

          if (andLogic) {
            matches = true; // If we got here with AND logic, all terms matched
          }

          if (matches) {
            matchCount++;
          }

          return matches;
        });
      }
    }

    // Apply exclude filter
    // Remove lines that contain any of the exclude terms
    if (excludeTerm) {
      const excludeTerms = excludeTerm.split(/\s+/).filter(term => term.length > 0);
      filteredLines = filteredLines.filter(line => {
        for (const term of excludeTerms) {
          const lowerLine = caseInsensitive ? line.toLowerCase() : line;
          const lowerTerm = caseInsensitive ? term.toLowerCase() : term;

          if (wholeWord) {
            const regex = new RegExp(`\\b${this.escapeRegExp(lowerTerm)}\\b`, caseInsensitive ? 'i' : '');
            if (regex.test(lowerLine)) {
              return false;
            }
          } else if (lowerLine.includes(lowerTerm)) {
            return false;
          }
        }
        return true;
      });
    }

    // Apply severity filter
    // Look for various patterns indicating severity levels
    if (severityFilter) {
      filteredLines = filteredLines.filter(line => {
        // Check for different severity format patterns
        const severityPatterns = [
          `[${severityFilter}]`,
          ` ${severityFilter} `,
          `|${severityFilter}|`,
          `-${severityFilter}-`
        ];

        return severityPatterns.some(pattern => line.includes(pattern)) || 
               line.toUpperCase().includes(severityFilter.toUpperCase());
      });
    }

    // Apply duplicate filter
    // Remove duplicate lines if option is enabled
    if (hideDuplicates) {
      const seenLines = new Set();
      filteredLines = filteredLines.filter(line => {
        if (seenLines.has(line)) {
          return false;
        }
        seenLines.add(line);
        return true;
      });
    }

    // Calculate unique lines count for statistics
    filteredLines.forEach(line => uniqueLines.add(line));

    // Apply context lines expansion
    // This adds surrounding lines to provide more context around matches
    if (contextLines > 0 && filteredLines.length > 0) {
      // Find the original indices of matching lines
      const originalLines = this.fileContent;
      const matchingIndices = new Set();

      // Find which original indices match our current filtered results
      for (const filteredLine of filteredLines) {
        const originalIndex = originalLines.indexOf(filteredLine);
        if (originalIndex !== -1) {
          // Add context lines around this match
          for (let i = Math.max(0, originalIndex - contextLines); 
               i <= Math.min(originalLines.length - 1, originalIndex + contextLines); i++) {
            matchingIndices.add(i);
          }
        }
      }

      // Get lines at those indices
      const resultWithContext = [];
      for (const idx of Array.from(matchingIndices).sort((a, b) => a - b)) {
        resultWithContext.push(originalLines[idx]);
      }

      // Remove duplicates while preserving order
      const uniqueResult = [...new Set(resultWithContext)];
      filteredLines = uniqueResult;
    }

    // Display results
    if (contextLines > 0) {
      this.displayLogContentWithContext(this.fileContent, filteredLines, contextLines);
    } else {
      this.displayLogContent(filteredLines);
    }

    // Update statistics
    document.querySelector(this.SELECTORS.matchCount).textContent = matchCount;
    document.querySelector(this.SELECTORS.uniqueLines).textContent = uniqueLines.size;
    document.querySelector(this.SELECTORS.resultsInfo).textContent = `${filteredLines.length} results`;
  }

  /**
   * Displays the log content in the main results area
   * Each line includes a line number and properly formatted content
   * @param {Array} logLines - Array of log lines to display
   */
  displayLogContent(logLines) {
    const container = document.querySelector(this.SELECTORS.logContent);
    container.innerHTML = '';

    logLines.forEach((line, index) => {
      const lineDiv = document.createElement('div');
      lineDiv.className = 'log-line';
      lineDiv.innerHTML = `
        <span class="line-number">${index + 1}</span>
        <div class="log-content">${this.formatLogLine(line)}</div>
      `;
      container.appendChild(lineDiv);
    });
  }

  /**
   * Displays log content with context lines highlighted differently
   * Matched lines are shown normally, while context lines have a different style
   * @param {Array} originalLines - Full set of original log lines
   * @param {Array} filteredLines - Lines that match the search criteria
   * @param {number} contextLines - Number of context lines to show around matches
   */
  displayLogContentWithContext(originalLines, filteredLines, contextLines) {
    const container = document.querySelector(this.SELECTORS.logContent);
    container.innerHTML = '';

    // Create a set of indices that are matches to identify context lines
    const matchIndices = new Set();
    filteredLines.forEach(line => {
      const idx = originalLines.indexOf(line);
      if (idx !== -1) {
        matchIndices.add(idx);
      }
    });

    // Find all lines that should be displayed (matches + context)
    const indicesToDisplay = new Set();

    matchIndices.forEach(matchIdx => {
      // Add match and its context
      for (let i = Math.max(0, matchIdx - contextLines); 
           i <= Math.min(originalLines.length - 1, matchIdx + contextLines); i++) {
        indicesToDisplay.add(i);
      }
    });

    // Display in order
    Array.from(indicesToDisplay).sort((a, b) => a - b).forEach(idx => {
      const line = originalLines[idx];
      const lineDiv = document.createElement('div');

      if (matchIndices.has(idx)) {
        lineDiv.className = 'log-line';  // Matched line (no special highlight)
      } else {
        lineDiv.className = 'log-line context-line';  // Context line (different style)
      }

      lineDiv.innerHTML = `
        <span class="line-number">${idx + 1}</span>
        <div class="log-content">${this.formatLogLine(line)}</div>
      `;
      container.appendChild(lineDiv);
    });
  }

  /**
   * Formats a log line by applying syntax highlighting for severity and timestamps
   * Also highlights search terms if a search is active
   * @param {string} line - A single log line to format
   * @returns {string} - HTML formatted log line
   */
  formatLogLine(line) {
    // Detect and format severity levels with appropriate colors
    let formattedLine = line;
    if (line.includes('[ERROR]')) {
      formattedLine = formattedLine.replace(/\[ERROR\]/, '<span class="severity-error">[ERROR]</span>');
    } else if (line.includes('[WARN]')) {
      formattedLine = formattedLine.replace(/\[WARN\]/, '<span class="severity-warn">[WARN]</span>');
    } else if (line.includes('[INFO]')) {
      formattedLine = formattedLine.replace(/\[INFO\]/, '<span class="severity-info">[INFO]</span>');
    } else if (line.includes('[DEBUG]')) {
      formattedLine = formattedLine.replace(/\[DEBUG\]/, '<span class="severity-debug">[DEBUG]</span>');
    }

    // Detect and format timestamp patterns
    const timestampRegex = /(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/g;
    formattedLine = formattedLine.replace(timestampRegex, '<span class="timestamp">$1</span>');

    // Highlight search terms if there's an active search
    const searchTerm = document.querySelector(this.SELECTORS.searchInput).value.trim();
    if (searchTerm) {
      const caseInsensitive = document.querySelector(this.SELECTORS.caseInsensitive).checked;
      const wholeWord = document.querySelector(this.SELECTORS.wholeWord).checked;

      // Split search term into multiple keywords for highlighting
      const searchTerms = searchTerm.split(/\s+/).filter(term => term.length > 0);

      for (const term of searchTerms) {
        if (caseInsensitive) {
          if (wholeWord) {
            const regex = new RegExp(`\\b(${this.escapeRegExp(term)})\\b`, 'gi');
            formattedLine = formattedLine.replace(regex, '<span class="search-match">$1</span>');
          } else {
            const regex = new RegExp(`(${this.escapeRegExp(term)})`, 'gi');
            formattedLine = formattedLine.replace(regex, '<span class="search-match">$1</span>');
          }
        } else {
          if (wholeWord) {
            const regex = new RegExp(`\\b(${this.escapeRegExp(term)})\\b`, 'g');
            formattedLine = formattedLine.replace(regex, '<span class="search-match">$1</span>');
          } else {
            const regex = new RegExp(`(${this.escapeRegExp(term)})`, 'g');
            formattedLine = formattedLine.replace(regex, '<span class="search-match">$1</span>');
          }
        }
      }
    }

    return formattedLine;
  }

  /**
   * Resets all filters to their default state and displays the full log content
   */
  resetFilters() {
    document.querySelector(this.SELECTORS.searchInput).value = '';
    document.querySelector(this.SELECTORS.excludeInput).value = '';
    document.querySelector(this.SELECTORS.caseInsensitive).checked = true;
    document.querySelector(this.SELECTORS.wholeWord).checked = false;
    document.querySelector(this.SELECTORS.andLogic).checked = true;
    document.querySelector(this.SELECTORS.contextLines).value = 0;
    document.querySelector(this.SELECTORS.severityFilter).value = '';
    document.querySelector(this.SELECTORS.hideDuplicates).checked = false;

    // Reset column-based filter
    document.querySelector(this.SELECTORS.columnSelect).value = '';
    document.querySelector(this.SELECTORS.columnOperator).value = 'equals';
    document.querySelector(this.SELECTORS.columnValue).value = '';

    this.displayLogContent(this.fileContent);
    document.querySelector(this.SELECTORS.matchCount).textContent = '0';
    document.querySelector(this.SELECTORS.uniqueLines).textContent = new Set(this.fileContent).size;
    document.querySelector(this.SELECTORS.resultsInfo).textContent = `${this.fileContent.length} results`;
  }

  /**
   * Copies the currently displayed results to the clipboard
   */
  copyResults() {
    const logContent = document.querySelector(this.SELECTORS.logContent);
    const textToCopy = Array.from(logContent.children)
      .map(child => child.innerText)
      .join('\n');

    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        alert('Results copied to clipboard!');
      })
      .catch(err => {
        console.error('Failed to copy: ', err);
      });
  }

  /**
   * Exports the currently displayed results to a text file
   */
  exportResults() {
    const logContent = document.querySelector(this.SELECTORS.logContent);
    const textToExport = Array.from(logContent.children)
      .map(child => child.innerText)
      .join('\n');

    const blob = new Blob([textToExport], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `filtered_logs_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();

    // Clean up
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  }

  /**
   * Escapes special regex characters in a string to prevent regex errors
   * @param {string} string - String to escape
   * @returns {string} - Escaped string safe for regex use
   */
  escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
}

// Initialize the dashboard when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Get file content and stats from the server via the template context
  // These variables are populated by Flask's render_template function
  const fileContent = window.file_content || [];
  const stats = window.stats || {};

  // Initialize the analyzer
  new LogAnalyzer(fileContent, stats);
});