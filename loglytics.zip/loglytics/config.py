"""
Configuration Module for LogLytics

This module defines the application configuration settings
using Flask's configuration pattern. It includes settings
for file uploads, storage paths, and other application-level
configuration options.

The Config class contains all the configuration variables
needed by the Flask application. These settings can be
easily modified to adapt the application to different environments.

Key configuration aspects:
- File upload settings (folder, size limits)
- Storage directory management
- Security and performance parameters
"""

import os

class Config:
    """
    Main configuration class for the LogLytics application.
    
    This class contains all the configuration variables needed
    by the Flask application. It follows Flask's configuration
    pattern where configuration variables are defined as class attributes.
    
    Configuration variables:
    - UPLOAD_FOLDER: Directory where uploaded files are stored
    - MAX_CONTENT_LENGTH: Maximum allowed file size for uploads
    """
    
    # Upload configurations
    # Directory where uploaded files will be stored
    UPLOAD_FOLDER = 'storage'
    
    # Maximum allowed file size for uploads (20MB in bytes)
    # This helps prevent denial-of-service attacks through large file uploads
    MAX_CONTENT_LENGTH = 20 * 1024 * 1024  # 20MB max file size

# Create upload directory if it doesn't exist
# This ensures the application can start even if the storage directory is missing
if not os.path.exists(Config.UPLOAD_FOLDER):
    os.makedirs(Config.UPLOAD_FOLDER)